const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  try {
    console.log('[getCheckinList] 开始获取入住人员列表...')

    // 获取所有入住记录
    const result = await db.collection('checkin_records')
      .orderBy('checkin_time', 'desc')
      .get()

    const records = result.data || []
    console.log('[getCheckinList] 入住记录总数:', records.length)

    // 格式化数据，确保字段名称一致
    const formattedRecords = records.map(record => ({
      id: record._id,
      check_in_id: record._id, // 使用 _id 作为 check_in_id
      bed_id: record.bed_id,
      name: record.person_name,
      id_card: record.person_id,
      phone: record.phone,
      checkin_time: record.checkin_time,
      floor: record.floor,
      bed_number: record.bed_number,
      position: record.position,
      dormitory: record.dormitory,
      room: record.room,
      station_name: record.station_name || null,
      is_flagged: record.is_flagged || false,
      payment_type: record.payment_type,
      payment_amount: record.payment_amount,
      remark: record.remark
    }))

    return {
      code: 200,
      msg: '获取入住人员列表成功',
      data: formattedRecords
    }
  } catch (error) {
    console.error('[getCheckinList] 获取入住人员列表失败:', error)
    return {
      code: 500,
      msg: '获取入住人员列表失败: ' + error.message,
      data: []
    }
  }
}
