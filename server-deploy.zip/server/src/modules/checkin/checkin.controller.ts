import { Controller, Post, Body, Get, Query, Param } from '@nestjs/common';
import { CheckInService } from './checkin.service';

@Controller('checkin')
export class CheckInController {
  constructor(private readonly checkInService: CheckInService) {}

  @Post()
  async checkIn(@Body() body: { bedId: number; name: string; idCard: string; phone: string; checkInDate?: string }) {
    console.log('入住登记请求:', body);
    return await this.checkInService.checkIn(
      body.bedId, 
      body.name, 
      body.idCard, 
      body.phone,
      body.checkInDate
    );
  }

  @Post('transfer')
  async transferBed(@Body() body: { checkInId: number; targetBedId: number }) {
    console.log('转移床位请求:', body);
    return await this.checkInService.transferBed(
      body.checkInId,
      body.targetBedId
    );
  }

  @Post('update-date')
  async updateCheckInDate(@Body() body: { checkInId: number; checkInDate: string }) {
    console.log('更新入住日期请求:', body);
    return await this.checkInService.updateCheckInDate(
      body.checkInId,
      body.checkInDate
    );
  }

  @Get('search')
  async searchResident(@Query('keyword') keyword: string) {
    console.log('搜索人员请求:', keyword);
    return await this.checkInService.searchResident(keyword);
  }

  @Get('list')
  async getAllCheckIns() {
    console.log('获取所有入住人员请求');
    return await this.checkInService.getAllCheckIns();
  }

  @Post('list')
  async getAllCheckInsPost() {
    console.log('获取所有入住人员请求 (POST)');
    return await this.checkInService.getAllCheckIns();
  }

  @Post('toggle-station')
  async toggleStationMarked(@Body() body: { checkInId: number; stationName: string | null }) {
    console.log('设置站点标注请求:', body);
    return await this.checkInService.setStationMarked(body.checkInId, body.stationName);
  }

  @Post('toggle-rider')
  async toggleRider(@Body() body: { checkInId: number; value?: boolean }) {
    console.log('切换骑手状态请求:', body);
    return await this.checkInService.toggleRider(body.checkInId, body.value);
  }

  @Post('toggle-flag')
  async toggleFlag(@Body() body: { checkInId: number }) {
    console.log('切换红名标记请求:', body);
    return await this.checkInService.toggleFlag(body.checkInId);
  }

  @Get('flagged')
  async getFlaggedPeople() {
    console.log('获取红名人员请求');
    return await this.checkInService.getFlaggedPeople();
  }

  @Get('swap-candidates/:checkInId')
  async getSwapCandidates(@Param('checkInId') checkInId: string) {
    console.log('获取互换候选请求:', checkInId);
    return await this.checkInService.getSwapCandidates(parseInt(checkInId, 10));
  }
}
